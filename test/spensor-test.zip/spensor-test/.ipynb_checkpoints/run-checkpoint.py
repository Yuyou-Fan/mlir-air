import air
import air.compiler.util
from air.dialects import linalg, tensor, arith, func, memref
from air.ir import *
import air.passmanager
from air.dialects import air as airdialect
from air.compiler.util import run_transform
import sys

with air.ir.Context() as ctx, Location.unknown():

    ################################################
    ## Tiling
    ################################################

    air_tiled_ir_string = """
builtin.module {
  func.func @reduce(%0 : memref<16x2048xf32, 0 : i32>, %1 : memref<16x1xf32, 0 : i32>) {
    %autogen_zero = arith.constant 0 : index
    %autogen_one = arith.constant 1 : index
    %autogen_4_index = arith.constant 4 : index
    "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
    ^0(%2 : index):
      %3 = memref.subview %1[0, 0] [16, 1] [1, 1] : memref<16x1xf32, 0 : i32> to memref<16x1xf32, strided<[1, 1]>, 0 : i32>
      %4 = memref.subview %0[0, 0] [16, 2048] [1, 1] : memref<16x2048xf32, 0 : i32> to memref<16x2048xf32, strided<[2048, 1]>, 0 : i32>
      %5 = affine.apply affine_map<()[s0] -> (s0)> ()[%2]
      %6 = memref.alloc() : memref<16x2048xf32, 1 : i32>
      "memref.copy"(%4, %6) : (memref<16x2048xf32, strided<[2048, 1]>, 0 : i32>, memref<16x2048xf32, 1 : i32>) -> ()
      %7 = memref.alloc() : memref<16x4xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_4_index, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%8 : index):
        %9 = affine.apply affine_map<()[s0] -> ((s0 * 512))> ()[%8]
        %10 = memref.subview %6[0, %9] [16, 512] [1, 1] : memref<16x2048xf32, 1 : i32> to memref<16x512xf32, strided<[2048, 1], offset: ?>, 1 : i32>
        %11 = affine.apply affine_map<()[s0] -> (s0)> ()[%8]
        %12 = memref.alloc() : memref<16x512xf32, 2 : i32>
        "memref.copy"(%10, %12) : (memref<16x512xf32, strided<[2048, 1], offset: ?>, 1 : i32>, memref<16x512xf32, 2 : i32>) -> ()
        %13 = memref.alloc() : memref<16x1xf32, 2 : i32>
        %14 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%14 : f32) outs(%13 : memref<16x1xf32, 2 : i32>)
        %autogen_0_index = arith.constant 0 : index
        %autogen_1_index = arith.constant 1 : index
        %autogen_16_index = arith.constant 16 : index
        %autogen_512_index = arith.constant 512 : index
        scf.for %15 = %autogen_0_index to %autogen_16_index step %autogen_1_index {
          scf.for %16 = %autogen_0_index to %autogen_512_index step %autogen_1_index {
            %17 = memref.load %12[%15, %16] : memref<16x512xf32, 2 : i32>
            %18 = arith.constant 0 : index
            %19 = memref.load %13[%15, %18] : memref<16x1xf32, 2 : i32>
            %20 = arith.addf %17, %19 : f32
            memref.store %20, %13[%15, %18] : memref<16x1xf32, 2 : i32>
          }
        }
        %21 = affine.apply affine_map<()[s0] -> (s0)> ()[%8]
        %22 = memref.subview %7[0, %21] [16, 1] [1, 1] : memref<16x4xf32, 1 : i32> to memref<16x1xf32, strided<[4, 1], offset: ?>, 1 : i32>
        "memref.copy"(%13, %22) : (memref<16x1xf32, 2 : i32>, memref<16x1xf32, strided<[4, 1], offset: ?>, 1 : i32>) -> ()
        memref.dealloc %12 : memref<16x512xf32, 2 : i32>
        memref.dealloc %13 : memref<16x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      %23 = memref.alloc() : memref<16x1xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^2(%24 : index):
        %25 = affine.apply affine_map<()[s0] -> (s0)> ()[%2]
        %26 = memref.alloc() : memref<16x4xf32, 2 : i32>
        "memref.copy"(%7, %26) : (memref<16x4xf32, 1 : i32>, memref<16x4xf32, 2 : i32>) -> ()
        %27 = memref.alloc() : memref<16x1xf32, 2 : i32>
        %28 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%28 : f32) outs(%27 : memref<16x1xf32, 2 : i32>)
        %autogen_0_index_1 = arith.constant 0 : index
        %autogen_1_index_1 = arith.constant 1 : index
        %autogen_16_index_1 = arith.constant 16 : index
        %autogen_4_index_1 = arith.constant 4 : index
        scf.for %29 = %autogen_0_index_1 to %autogen_16_index_1 step %autogen_1_index_1 {
          scf.for %30 = %autogen_0_index_1 to %autogen_4_index_1 step %autogen_1_index_1 {
            %31 = memref.load %26[%29, %30] : memref<16x4xf32, 2 : i32>
            %32 = arith.constant 0 : index
            %33 = memref.load %27[%29, %32] : memref<16x1xf32, 2 : i32>
            %34 = arith.addf %31, %33 : f32
            memref.store %34, %27[%29, %32] : memref<16x1xf32, 2 : i32>
          }
        }
        %35 = affine.apply affine_map<()[s0] -> (s0)> ()[%24]
        "memref.copy"(%27, %23) : (memref<16x1xf32, 2 : i32>, memref<16x1xf32, 1 : i32>) -> ()
        memref.dealloc %26 : memref<16x4xf32, 2 : i32>
        memref.dealloc %27 : memref<16x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%23, %3) : (memref<16x1xf32, 1 : i32>, memref<16x1xf32, strided<[1, 1]>, 0 : i32>) -> ()
      memref.dealloc %6 : memref<16x2048xf32, 1 : i32>
      memref.dealloc %7 : memref<16x4xf32, 1 : i32>
      memref.dealloc %23 : memref<16x1xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index) -> ()
    func.return
  }
}
    """
    air_module = Module.parse(air_tiled_ir_string)
    #print(air_module)

    ################################################
    ## Binding scf.paralell to air hierarchies
    ################################################

    pipeline = (
        "builtin.module("
        + ",".join(
            [
                # Convert to AIR Option 1
                "air-insert-launch-around-herd{insert-segment=true}",
                 "func.func(air-lower-herd-parallel)",
                # # Convert to AIR option 2
                 "air-par-to-herd{depth=-1}",
                 "air-par-to-launch{depth=0 has-air-segment=true}",
                 "scf-forall-to-for",
                # # End
                 "air-copy-to-dma",
                #  "air-dependency",
                # "air-dependency-schedule-opt",
                # "air-specialize-dma-broadcast",
                # "air-dma-to-channel,canonicalize",
                # "cse",
                # "air-dependency-canonicalize",
                # "canonicalize",
                # "cse",
                # "air-isolate-async-dma-loop-nests",
                # "canonicalize,cse",
                # "air-fuse-channels",
                # "canonicalize,cse",
                # "func.func(air-split-l2-memref)",
                # "canonicalize,cse",
                # "air-isolate-async-dma-loop-nests",
                # "canonicalize,cse",
                # "func.func(air-fuse-alloc-dealloc)",
                # "func.func(air-shrink-memref-sizes-by-access)",
                # "func.func(convert-linalg-to-loops)",
                # "func.func(air-opt-memtile-dma-bds{device=npu1_4col})",
                # "canonicalize,cse",
                # "func.func(air-collapse-herd{max-col-size=4 })",
                # "canonicalize,cse",
                # "air-place-herds{num-rows=6 num-cols=4 row-anchor=2 col-anchor=0}",
                # "canonicalize,cse",
                # "func.func(air-renumber-dma)"
            ]
        )
        + ")"
    )
    pm = air.passmanager.PassManager.parse(pipeline)
    pm.run(air_module.operation)
    #print(air_module)

    # ################################################
    # ## MLIR-AIR to MLIR-AIE
    # ################################################

    # pipeline = (
    #     "builtin.module("
    #     + ",".join(
    #         [
    #             "canonicalize",
    #             "cse",
    #             "air-to-aie{row-offset=2 col-offset=0 device=npu1_4col emit-while-loop=true}",
    #             "canonicalize",
    #         ]
    #     )
    #     + ")"
    # )
    # pm = air.passmanager.PassManager.parse(pipeline)
    # pm.run(air_module.operation)
    # #print(air_module)

    # # ################################################
    # # ## MLIR-AIR runtime lowering
    # # ################################################

    # pipeline = (
    #     "builtin.module("
    #     + ",".join(
    #         [
    #             "func.func(air-opt-shim-dma-bds{device=npu1_4col shim-dma-tile-sizes=4,4})",
    #             "air-to-std",
    #             "canonicalize",
    #             "symbol-dce",
    #             "affine-expand-index-ops",
    #             "airrt-to-npu",
    #             "canonicalize",
    #         ]
    #     )
    #     + ")"
    # )
    # pm = air.passmanager.PassManager.parse(pipeline)
    # pm.run(air_module.operation)
    with open("aieDebug.mlir", "w") as f:
        print(air_module)
        f.write(str(air_module))
