# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """

builtin.module {
  func.func @"4096_add"(%0 : memref<4096x4096xf32>, %1 : memref<4096x4096xf32>, %2 : memref<4096x4096xf32>) {
    %autogen_0_index = arith.constant 0 : index
    %autogen_1_index = arith.constant 1 : index
    %autogen_64_index = arith.constant 64 : index
    %3 = bufferization.to_tensor %2 restrict writable : memref<4096x4096xf32> to tensor<4096x4096xf32>
    %4 = bufferization.to_tensor %1 restrict writable : memref<4096x4096xf32> to tensor<4096x4096xf32>
    %5 = bufferization.to_tensor %0 restrict writable : memref<4096x4096xf32> to tensor<4096x4096xf32>
    "scf.parallel"(%autogen_0_index, %autogen_0_index, %autogen_64_index, %autogen_64_index, %autogen_1_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
    ^0(%6 : index, %7 : index):
      %8 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<64x64xf32>
      %9 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<64x64xf32>
      %10 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<64x64xf32>
      %11 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%6]
      %12 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%7]
      %13 = "tensor.extract_slice"(%5, %11, %12, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 64, 64>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<4096x4096xf32>, index, index, index, index) -> tensor<64x64xf32>
      %14 = linalg.copy ins(%13 : tensor<64x64xf32>) outs(%10 : tensor<64x64xf32>) -> tensor<64x64xf32>
      %15 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%6]
      %16 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%7]
      %17 = "tensor.extract_slice"(%4, %15, %16, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 64, 64>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<4096x4096xf32>, index, index, index, index) -> tensor<64x64xf32>
      %18 = linalg.copy ins(%17 : tensor<64x64xf32>) outs(%9 : tensor<64x64xf32>) -> tensor<64x64xf32>
      "scf.parallel"(%autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index, %autogen_1_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
      ^1(%19 : index, %20 : index):
        %21 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<64x64xf32>
        %22 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<64x64xf32>
        %23 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<64x64xf32>
        %24 = affine.apply affine_map<()[s0] -> (s0)> ()[%19]
        %25 = affine.apply affine_map<()[s0] -> (s0)> ()[%20]
        %26 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%24]
        %27 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%25]
        %28 = "tensor.extract_slice"(%9, %26, %27, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 64, 64>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<64x64xf32>, index, index, index, index) -> tensor<64x64xf32>
        %29 = linalg.copy ins(%28 : tensor<64x64xf32>) outs(%23 : tensor<64x64xf32>) -> tensor<64x64xf32>
        %30 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%24]
        %31 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%25]
        %32 = "tensor.extract_slice"(%10, %30, %31, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 64, 64>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<64x64xf32>, index, index, index, index) -> tensor<64x64xf32>
        %33 = linalg.copy ins(%32 : tensor<64x64xf32>) outs(%22 : tensor<64x64xf32>) -> tensor<64x64xf32>
        %34 = linalg.add ins(%22, %23 : tensor<64x64xf32>, tensor<64x64xf32>) outs(%21 : tensor<64x64xf32>) -> tensor<64x64xf32>
        %35 = "tensor.extract_slice"(%21, %autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 64, 64>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<64x64xf32>, index, index, index, index) -> tensor<64x64xf32>
        %36 = linalg.copy ins(%35 : tensor<64x64xf32>) outs(%8 : tensor<64x64xf32>) -> tensor<64x64xf32>
        scf.reduce
      }) {memory_tag = "L1"} : (index, index, index, index, index, index) -> ()
      %37 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%6]
      %38 = affine.apply affine_map<()[s0] -> ((s0 * 64))> ()[%7]
      %39 = "tensor.extract_slice"(%3, %37, %38, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 64, 64>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<4096x4096xf32>, index, index, index, index) -> tensor<64x64xf32>
      %40 = linalg.copy ins(%8 : tensor<64x64xf32>) outs(%39 : tensor<64x64xf32>) -> tensor<64x64xf32>
      scf.reduce
    }) {memory_tag = "L2"} : (index, index, index, index, index, index) -> ()
    func.return
  }
}
        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    "one-shot-bufferize",
                     "convert-linalg-to-loops",
                     "canonicalize",
                     "memref-expand",
                    "normalize-memrefs",
                     "canonicalize",
                    # Convert to AIR Option 1
                    # "air-insert-launch-around-herd{insert-segment=true}",
                    #  "func.func(air-lower-herd-parallel)",
                    # # # Convert to AIR option 2
                    #  "air-par-to-herd{depth=-1}",
                    #  "air-par-to-launch{depth=0 has-air-segment=true}",
                    #  "scf-forall-to-for",
                    # # End
                    # "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        print(mlir_module)
        exit(0)
        

  
        shape = (4096,4096)
        total_size=4096*4096
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_a = input_a.astype(INPUT_DATATYPE)
        input_b = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_b = input_b.astype(INPUT_DATATYPE)
        num_samples = 1000
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 4096, num_samples),  # i indices
                np.random.randint(0, 4096, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                (input_a[i, j] + input_b[i, j]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (4096,4096),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        ###### Compile and test
        runner = XRTRunner(
            verbose=False,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a, input_b],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

