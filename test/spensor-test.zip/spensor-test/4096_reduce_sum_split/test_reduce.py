# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @reduce(%0 : memref<4096x4096xf32, 0 : i32>, %1 : memref<4096x1xf32, 0 : i32>) {
    %autogen_zero = arith.constant 0 : index
    %autogen_one = arith.constant 1 : index
    %autogen_1024_index = arith.constant 1024 : index
    "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
    ^0(%2 : index):
      %3 = memref.subview %1[0, 0] [4096, 1] [1, 1] : memref<4096x1xf32, 0 : i32> to memref<4096x1xf32, strided<[1, 1]>, 0 : i32>
      %4 = memref.subview %0[0, 0] [4096, 4096] [1, 1] : memref<4096x4096xf32, 0 : i32> to memref<4096x4096xf32, strided<[4096, 1]>, 0 : i32>
      %5 = affine.apply affine_map<()[s0] -> (s0)> ()[%2]
      %6 = memref.alloc() : memref<4096x4096xf32, 1 : i32>
      "memref.copy"(%4, %6) : (memref<4096x4096xf32, strided<[4096, 1]>, 0 : i32>, memref<4096x4096xf32, 1 : i32>) -> ()
      %7 = memref.alloc() : memref<4096x1024xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_1024_index, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%8 : index):
        %9 = affine.apply affine_map<()[s0] -> ((s0 * 4))> ()[%8]
        %10 = memref.subview %6[0, %9] [4096, 4] [1, 1] : memref<4096x4096xf32, 1 : i32> to memref<4096x4xf32, strided<[4096, 1], offset: ?>, 1 : i32>
        %11 = affine.apply affine_map<()[s0] -> (s0)> ()[%8]
        %12 = memref.alloc() : memref<4096x4xf32, 2 : i32>
        "memref.copy"(%10, %12) : (memref<4096x4xf32, strided<[4096, 1], offset: ?>, 1 : i32>, memref<4096x4xf32, 2 : i32>) -> ()
        %13 = memref.alloc() : memref<4096x1xf32, 2 : i32>
        %14 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%14 : f32) outs(%13 : memref<4096x1xf32, 2 : i32>)
        %autogen_0_index = arith.constant 0 : index
        %autogen_1_index = arith.constant 1 : index
        %autogen_4096_index = arith.constant 4096 : index
        %autogen_4_index = arith.constant 4 : index
        scf.for %15 = %autogen_0_index to %autogen_4096_index step %autogen_1_index {
          scf.for %16 = %autogen_0_index to %autogen_4_index step %autogen_1_index {
            %17 = memref.load %12[%15, %16] : memref<4096x4xf32, 2 : i32>
            %18 = arith.constant 0 : index
            %19 = memref.load %13[%15, %18] : memref<4096x1xf32, 2 : i32>
            %20 = arith.addf %17, %19 : f32
            memref.store %20, %13[%15, %18] : memref<4096x1xf32, 2 : i32>
          }
        }
        %21 = affine.apply affine_map<()[s0] -> (s0)> ()[%8]
        %22 = memref.subview %7[0, %21] [4096, 1] [1, 1] : memref<4096x1024xf32, 1 : i32> to memref<4096x1xf32, strided<[1024, 1], offset: ?>, 1 : i32>
        "memref.copy"(%13, %22) : (memref<4096x1xf32, 2 : i32>, memref<4096x1xf32, strided<[1024, 1], offset: ?>, 1 : i32>) -> ()
        memref.dealloc %12 : memref<4096x4xf32, 2 : i32>
        memref.dealloc %13 : memref<4096x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      %23 = memref.alloc() : memref<4096x1xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^2(%24 : index):
        %25 = affine.apply affine_map<()[s0] -> (s0)> ()[%2]
        %26 = memref.alloc() : memref<4096x1024xf32, 2 : i32>
        "memref.copy"(%7, %26) : (memref<4096x1024xf32, 1 : i32>, memref<4096x1024xf32, 2 : i32>) -> ()
        %27 = memref.alloc() : memref<4096x1xf32, 2 : i32>
        %28 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%28 : f32) outs(%27 : memref<4096x1xf32, 2 : i32>)
        %autogen_0_index_1 = arith.constant 0 : index
        %autogen_1_index_1 = arith.constant 1 : index
        %autogen_4096_index_1 = arith.constant 4096 : index
        %autogen_1024_index_1 = arith.constant 1024 : index
        scf.for %29 = %autogen_0_index_1 to %autogen_4096_index_1 step %autogen_1_index_1 {
          scf.for %30 = %autogen_0_index_1 to %autogen_1024_index_1 step %autogen_1_index_1 {
            %31 = memref.load %26[%29, %30] : memref<4096x1024xf32, 2 : i32>
            %32 = arith.constant 0 : index
            %33 = memref.load %27[%29, %32] : memref<4096x1xf32, 2 : i32>
            %34 = arith.addf %31, %33 : f32
            memref.store %34, %27[%29, %32] : memref<4096x1xf32, 2 : i32>
          }
        }
        %35 = affine.apply affine_map<()[s0] -> (s0)> ()[%24]
        "memref.copy"(%27, %23) : (memref<4096x1xf32, 2 : i32>, memref<4096x1xf32, 1 : i32>) -> ()
        memref.dealloc %26 : memref<4096x1024xf32, 2 : i32>
        memref.dealloc %27 : memref<4096x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%23, %3) : (memref<4096x1xf32, 1 : i32>, memref<4096x1xf32, strided<[1, 1]>, 0 : i32>) -> ()
      memref.dealloc %6 : memref<4096x4096xf32, 1 : i32>
      memref.dealloc %7 : memref<4096x1024xf32, 1 : i32>
      memref.dealloc %23 : memref<4096x1xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index) -> ()
    func.return
  }
}

        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        
        
        shape = (4096,4096)
        total_size=4096*4096
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        print(input_a)
        input_a = input_a.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 4096, num_samples),  # i indices
                np.random.randint(0, 1, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                sum(input_a[i]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (4096,1),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        outputs = np.array([sum(input_a[i]) for i in range(4096)],dtype=INPUT_DATATYPE).reshape((4096,1))
        ###### Compile and test
        runner = XRTRunner(
            verbose=True,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a],
                # expected_outputs=[outputs],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

