# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """

#map = affine_map<()[s0] -> (s0 * 16)>
#map1 = affine_map<()[s0] -> (s0)>
module {
  func.func @"64_add"(%arg0: memref<64x64xf32>, %arg1: memref<64x64xf32>, %arg2: memref<64x64xf32>) {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    scf.parallel (%arg3, %arg4) = (%c0, %c0) to (%c4, %c4) step (%c1, %c1) {
      %alloc = memref.alloc() {alignment = 64 : i64} : memref<16x16xf32, 1>
      %alloc_0 = memref.alloc() {alignment = 64 : i64} : memref<16x16xf32, 1>
      %alloc_1 = memref.alloc() {alignment = 64 : i64} : memref<16x16xf32, 1>
      %0 = affine.apply #map()[%arg3]
      %1 = affine.apply #map()[%arg4]
      %subview = memref.subview %arg0[%0, %1] [16, 16] [%c1, %c1] : memref<64x64xf32> to memref<16x16xf32, strided<[?, ?], offset: ?>>
      linalg.copy ins(%subview : memref<16x16xf32, strided<[?, ?], offset: ?>>) outs(%alloc_1 : memref<16x16xf32, 1>)
      %2 = affine.apply #map()[%arg3]
      %3 = affine.apply #map()[%arg4]
      %subview_2 = memref.subview %arg1[%2, %3] [16, 16] [%c1, %c1] : memref<64x64xf32> to memref<16x16xf32, strided<[?, ?], offset: ?>>
      linalg.copy ins(%subview_2 : memref<16x16xf32, strided<[?, ?], offset: ?>>) outs(%alloc_0 : memref<16x16xf32, 1>)
      scf.parallel (%arg5, %arg6) = (%c0, %c0) to (%c1, %c1) step (%c1, %c1) {
        %alloc_4 = memref.alloc() {alignment = 64 : i64} : memref<16x16xf32, 2>
        %alloc_5 = memref.alloc() {alignment = 64 : i64} : memref<16x16xf32, 2>
        %alloc_6 = memref.alloc() {alignment = 64 : i64} : memref<16x16xf32, 2>
        %6 = affine.apply #map1()[%arg5]
        %7 = affine.apply #map1()[%arg6]
        %8 = affine.apply #map()[%arg5]
        %9 = affine.apply #map()[%arg6]
        %subview_7 = memref.subview %alloc_0[%8, %9] [16, 16] [%c1, %c1] : memref<16x16xf32, 1> to memref<16x16xf32, strided<[?, ?], offset: ?>, 1>
        linalg.copy ins(%subview_7 : memref<16x16xf32, strided<[?, ?], offset: ?>, 1>) outs(%alloc_6 : memref<16x16xf32, 2>)
        linalg.copy ins(%alloc_1 : memref<16x16xf32, 1>) outs(%alloc_5 : memref<16x16xf32, 2>)
        linalg.add ins(%alloc_5, %alloc_6 : memref<16x16xf32, 2>, memref<16x16xf32, 2>) outs(%alloc_4 : memref<16x16xf32, 2>)
        linalg.copy ins(%alloc_4 : memref<16x16xf32, 2>) outs(%alloc : memref<16x16xf32, 1>)
        scf.reduce 
      } {memory_tag = "L1"}
      %4 = affine.apply #map()[%arg3]
      %5 = affine.apply #map()[%arg4]
      %subview_3 = memref.subview %arg2[%4, %5] [16, 16] [%c1, %c1] : memref<64x64xf32> to memref<16x16xf32, strided<[?, ?], offset: ?>>
      linalg.copy ins(%alloc : memref<16x16xf32, 1>) outs(%subview_3 : memref<16x16xf32, strided<[?, ?], offset: ?>>)
      scf.reduce 
    } {memory_tag = "L2"}
    return
  }
}



        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        print(mlir_module)
        

        shape = (64,64)
        total_size=64*64
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_a = input_a.astype(INPUT_DATATYPE)
        input_b = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_b = input_b.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 64, num_samples),  # i indices
                np.random.randint(0, 64, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                (input_a[i, j] + input_b[i, j]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (64,64),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        ###### Compile and test
        runner = XRTRunner(
            verbose=False,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a, input_b],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

