# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @"64_add"(%0 : memref<2x2x32x32xf32>, %1 : memref<64x64xf32>, %2 : memref<32x32xf32>) {
    %autogen_0_index = arith.constant 0 : index
    %autogen_1_index = arith.constant 1 : index
    %autogen_64_index = arith.constant 64 : index
    %autogen_2_index = arith.constant 2 : index
    %autogen_32_index = arith.constant 32 : index
    %3 = bufferization.to_tensor %2 restrict writable : memref<32x32xf32> to tensor<32x32xf32>
    %4 = bufferization.to_tensor %1 restrict writable : memref<64x64xf32> to tensor<64x64xf32>
    %5 = bufferization.to_tensor %0 restrict writable : memref<2x2x32x32xf32> to tensor<2x2x32x32xf32>
    "scf.parallel"(%autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index, %autogen_1_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
    ^0(%6 : index, %7 : index):
      %10 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<2x2x32x32xf32>
      %11 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<32x32xf32>
      %19 = linalg.copy ins(%5 : tensor<2x2x32x32xf32>) outs(%10 : tensor<2x2x32x32xf32>) -> tensor<2x2x32x32xf32>
      "scf.parallel"(%autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index, %autogen_1_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
      ^2(%40 : index, %41 : index):
        %42 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<32x32xf32>
        %43 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<32x32xf32>
        %44 = affine.apply affine_map<()[s0] -> (s0)> ()[%40]
        %45 = affine.apply affine_map<()[s0] -> (s0)> ()[%41]
        %46 = arith.constant 0.000000e+00 : f32
        %47 = linalg.fill ins(%46 : f32) outs(%43 : tensor<32x32xf32>) -> tensor<32x32xf32>
        scf.for %48 = %autogen_0_index to %autogen_2_index step %autogen_1_index {
          scf.for %49 = %autogen_0_index to %autogen_2_index step %autogen_1_index {
            %50 = affine.apply affine_map<()[s0] -> (s0)> ()[%48]
            %51 = affine.apply affine_map<()[s0] -> (s0)> ()[%49]
            %52 = "tensor.extract_slice"(%10, %50, %51, %autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808, -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 1, 1, 32, 32>, static_strides = array<i64: -9223372036854775808, -9223372036854775808, -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 4, 0, 4>}> : (tensor<2x2x32x32xf32>, index, index, index, index, index, index, index, index) -> tensor<32x32xf32>
            %53 = linalg.copy ins(%52 : tensor<32x32xf32>) outs(%42 : tensor<32x32xf32>) -> tensor<32x32xf32>
            %54 = linalg.add ins(%43, %42 : tensor<32x32xf32>, tensor<32x32xf32>) outs(%43 : tensor<32x32xf32>) -> tensor<32x32xf32>
          }
        }
        %55 = linalg.copy ins(%43 : tensor<32x32xf32>) outs(%11 : tensor<32x32xf32>) -> tensor<32x32xf32>
        scf.reduce
      }) {memory_tag = "L1"} : (index, index, index, index, index, index) -> ()
      %56 = "tensor.extract_slice"(%3, %autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<32x32xf32>, index, index, index, index) -> tensor<32x32xf32>
      %57 = linalg.copy ins(%11 : tensor<32x32xf32>) outs(%56 : tensor<32x32xf32>) -> tensor<32x32xf32>
      scf.reduce
    }) {memory_tag = "L2"} : (index, index, index, index, index, index) -> ()
    func.return
  }
}
        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    "one-shot-bufferize",
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                    #  "convert-linalg-to-loops",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        print(mlir_module)
        #exit(0)
        

        shape = (64,64)
        total_size=64*64
        input_a = np.arange(0, total_size, dtype=np.int64).reshape((2,2,32,32))
        input_a = input_a.astype(INPUT_DATATYPE)
        input_b = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_b = input_b.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 32, num_samples),  # i indices
                np.random.randint(0, 32, num_samples),  # j indices
            ]
        )

        def getIJValue(i, j, input_a, input_b):
            result = 0
            for i1 in range(2):
                for j1 in range(2):
                    result += input_a[i1,j1,i,j]
            return result
        
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                getIJValue(i,j,input_a,input_a) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (32,32),
            "indices": sampled_indices,
            "values": sampled_values,
        }


        #outputs = np.array([[getIJValue(i, j, input_a, input_b) for j in range(32)] for i in range(32)],dtype=INPUT_DATATYPE).reshape((32,32))

        
        ###### Compile and test
        runner = XRTRunner(
            verbose=False,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a, input_a],
                #expected_outputs=[outputs],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

