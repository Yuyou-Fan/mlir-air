# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @reduce(%0 : memref<16x32xf32, 0 : i32>, %1 : memref<16x1xf32, 0 : i32>) {
    %autogen_zero = arith.constant 0 : index
    %autogen_one = arith.constant 1 : index
    %autogen_16_index = arith.constant 16 : index
    %autogen_1_index = arith.constant 1 : index
    "scf.parallel"(%autogen_zero, %autogen_zero, %autogen_16_index, %autogen_1_index, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
    ^0(%2 : index, %3 : index):
      %4 = affine.apply affine_map<()[s0] -> (s0)> ()[%2]
      %5 = memref.subview %1[%4, 0] [1, 1] [1, 1] : memref<16x1xf32, 0 : i32> to memref<1x1xf32, strided<[1, 1], offset: ?>, 0 : i32>
      %6 = affine.apply affine_map<()[s0] -> (s0)> ()[%2]
      %7 = memref.subview %0[%6, 0] [1, 32] [1, 1] : memref<16x32xf32, 0 : i32> to memref<1x32xf32, strided<[32, 1], offset: ?>, 0 : i32>
      %8 = affine.apply affine_map<()[s0, s1] -> ((s0 + s1))> ()[%2, %3]
      %9 = memref.alloc() : memref<1x32xf32, 1 : i32>
      "memref.copy"(%7, %9) : (memref<1x32xf32, strided<[32, 1], offset: ?>, 0 : i32>, memref<1x32xf32, 1 : i32>) -> ()
      %10 = memref.alloc() : memref<1x1xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%11 : index):
        %12 = affine.apply affine_map<()[s0, s1] -> ((s0 + s1))> ()[%2, %3]
        %13 = memref.alloc() : memref<1x32xf32, 2 : i32>
        "memref.copy"(%9, %13) : (memref<1x32xf32, 1 : i32>, memref<1x32xf32, 2 : i32>) -> ()
        %14 = memref.alloc() : memref<1x1xf32, 2 : i32>
        %15 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%15 : f32) outs(%14 : memref<1x1xf32, 2 : i32>)
        %16 = arith.constant 0 : index
        %17 = arith.constant 1 : index
        %18 = arith.constant 1 : index
        %19 = arith.constant 32 : index
        scf.for %20 = %16 to %18 step %17 {
          scf.for %21 = %16 to %19 step %17 {
            %22 = memref.load %13[%20, %21] : memref<1x32xf32, 2 : i32>
            %23 = arith.constant 0 : index
            %24 = memref.load %14[%20, %23] : memref<1x1xf32, 2 : i32>
            %25 = arith.addf %22, %24 : f32
            memref.store %25, %14[%20, %23] : memref<1x1xf32, 2 : i32>
          }
        }
        %26 = affine.apply affine_map<()[s0] -> (s0)> ()[%11]
        "memref.copy"(%14, %10) : (memref<1x1xf32, 2 : i32>, memref<1x1xf32, 1 : i32>) -> ()
        memref.dealloc %13 : memref<1x32xf32, 2 : i32>
        memref.dealloc %14 : memref<1x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%10, %5) : (memref<1x1xf32, 1 : i32>, memref<1x1xf32, strided<[1, 1], offset: ?>, 0 : i32>) -> ()
      memref.dealloc %9 : memref<1x32xf32, 1 : i32>
      memref.dealloc %10 : memref<1x1xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index, index, index, index) -> ()
    func.return
  }
}
        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        
        
        shape = (16,32)
        total_size=16*32
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        print(input_a)
        input_a = input_a.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 16, num_samples),  # i indices
                np.random.randint(0, 1, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                sum(input_a[i]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (16,1),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        outputs = np.array([sum(input_a[i]) for i in range(16)],dtype=INPUT_DATATYPE).reshape((16,1))
        ###### Compile and test
        runner = XRTRunner(
            verbose=True,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a],
                # expected_outputs=[outputs],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

