# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @elementwise_add(%arg0 : memref<16x32xf32, 0 : i32>, %arg1 : memref<16x1xf32, 0 : i32>) {
    %0 = arith.constant 0 : index
    %1 = arith.constant 1 : index
    %2 = arith.constant 16 : index
    %3 = arith.constant 1 : index
    "scf.parallel"(%0, %0, %2, %3, %1, %1) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
    ^0(%4 : index, %5 : index):
      %6 = affine.apply affine_map<()[s0] -> (s0)> ()[%4]
      %arg1_l3 = memref.subview %arg1[%6, 0] [1, 1] [1, 1] : memref<16x1xf32, 0 : i32> to memref<1x1xf32, strided<[1, 1], offset: ?>>
      %7 = affine.apply affine_map<()[s0] -> (s0)> ()[%4]
      %arg0_l3 = memref.subview %arg0[%7, 0] [1, 32] [1, 1] : memref<16x32xf32, 0 : i32> to memref<1x32xf32, strided<[32, 1], offset: ?>>
      %8 = affine.apply affine_map<()[s0, s1] -> ((s0 + s1))> ()[%4, %5]
      %arg0_l2 = memref.alloc() : memref<1x32xf32, 1 : i32>
      "memref.copy"(%arg0_l3, %arg0_l2) : (memref<1x32xf32, strided<[32, 1], offset: ?>>, memref<1x32xf32, 1 : i32>) -> ()
      %9 = arith.constant 0 : index
      %10 = arith.constant 1 : index
      %reduce_res_l2 = memref.alloc() : memref<1x1xf32, 1 : i32>
      "scf.parallel"(%9, %10, %10) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%11 : index):
        %12 = affine.apply affine_map<()[s0, s1] -> ((s0 + s1))> ()[%4, %5]
        %arg0_l1 = memref.alloc() : memref<1x32xf32, 2 : i32>
        "memref.copy"(%arg0_l2, %arg0_l1) : (memref<1x32xf32, 1 : i32>, memref<1x32xf32, 2 : i32>) -> ()
        %reduce_res_nd = memref.alloc() : memref<1x1xf32, 2 : i32>
        %13 = arith.constant 0 : index
        %14 = arith.constant 1 : index
        %15 = arith.constant 1 : index
        %16 = arith.constant 1 : index
        scf.for %17 = %13 to %15 step %14 {
          scf.for %18 = %13 to %16 step %14 {
            %19 = arith.constant 0.000000e+00 : f32
            memref.store %19, %reduce_res_nd[%17, %18] : memref<1x1xf32, 2 : i32>
          }
        }
        %20 = arith.constant 0 : index
        %21 = arith.constant 1 : index
        %22 = arith.constant 1 : index
        %23 = arith.constant 32 : index
        scf.for %24 = %20 to %22 step %21 {
          scf.for %25 = %20 to %23 step %21 {
            %26 = memref.load %arg0_l1[%24, %25] : memref<1x32xf32, 2 : i32>
            %27 = arith.constant 0 : index
            %28 = memref.load %reduce_res_nd[%24, %27] : memref<1x1xf32, 2 : i32>
            %29 = arith.addf %26, %28 : f32
            memref.store %29, %reduce_res_nd[%24, %27] : memref<1x1xf32, 2 : i32>
          }
        }
        %30 = affine.apply affine_map<()[s0] -> (s0)> ()[%11]
        "memref.copy"(%reduce_res_nd, %reduce_res_l2) : (memref<1x1xf32, 2 : i32>, memref<1x1xf32, 1 : i32>) -> ()
        memref.dealloc %arg0_l1 : memref<1x32xf32, 2 : i32>
        memref.dealloc %reduce_res_nd : memref<1x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%reduce_res_l2, %arg1_l3) : (memref<1x1xf32, 1 : i32>, memref<1x1xf32, strided<[1, 1], offset: ?>>) -> ()
      memref.dealloc %arg0_l2 : memref<1x32xf32, 1 : i32>
      memref.dealloc %reduce_res_l2 : memref<1x1xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index, index, index, index) -> ()
    func.return
  }
}
        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        
        
        shape = (16,32)
        total_size=16*32
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        print(input_a)
        input_a = input_a.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 16, num_samples),  # i indices
                np.random.randint(0, 1, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                sum(input_a[i]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (16,1),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        outputs = np.array([sum(input_a[i]) for i in range(16)],dtype=INPUT_DATATYPE).reshape((16,1))
        ###### Compile and test
        runner = XRTRunner(
            verbose=True,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a],
                # expected_outputs=[outputs],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

