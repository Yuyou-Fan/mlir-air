# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @reduce(%0 : memref<16x32xf32>, %1 : memref<16x1xf32>) {
    %autogen_0_index = arith.constant 0 : index
    %autogen_1_index = arith.constant 1 : index
    %autogen_16_index = arith.constant 16 : index
    %autogen_32_index = arith.constant 32 : index
    %autogen_8_index = arith.constant 8 : index
    %autogen_4_index = arith.constant 4 : index
    %autogen_2_index = arith.constant 2 : index
    %2 = bufferization.to_tensor %1 restrict writable : memref<16x1xf32> to tensor<16x1xf32>
    %3 = bufferization.to_tensor %0 restrict writable : memref<16x32xf32> to tensor<16x32xf32>
    %4 = arith.constant 0 : index
    %5 = arith.constant 1 : index
    %6 = arith.constant 4 : index
    "scf.parallel"(%autogen_0_index, %autogen_1_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
    ^0(%7 : index):
      %8 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<16x1xf32>
      %9 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<16x32xf32>
      %10 = bufferization.alloc_tensor() {memory_space = 1 : i64} : tensor<16x8xf32>
      %11 = affine.apply affine_map<()[s0] -> ((s0 * 32))> ()[%7]
      %12 = "tensor.extract_slice"(%3, %autogen_0_index, %11, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 16, 32>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<16x32xf32>, index, index, index, index) -> tensor<16x32xf32>
      %13 = linalg.copy ins(%12 : tensor<16x32xf32>) outs(%9 : tensor<16x32xf32>) -> tensor<16x32xf32>
      scf.for %14 = %autogen_0_index to %autogen_2_index step %autogen_1_index {
        "scf.parallel"(%autogen_0_index, %autogen_4_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
        ^1(%15 : index):
          %16 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<16x1xf32>
          %17 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<16x4xf32>
          %18 = affine.apply affine_map<()[s0, s1] -> (((s0 * 2) + s1))> ()[%15, %14]
          %19 = affine.apply affine_map<()[s0] -> ((s0 * 4))> ()[%18]
          %20 = "tensor.extract_slice"(%9, %autogen_0_index, %19, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 16, 4>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<16x32xf32>, index, index, index, index) -> tensor<16x4xf32>
          %21 = linalg.copy ins(%20 : tensor<16x4xf32>) outs(%17 : tensor<16x4xf32>) -> tensor<16x4xf32>
          %22 = arith.constant 0.000000e+00 : f32
          %23 = linalg.fill ins(%22 : f32) outs(%16 : tensor<16x1xf32>) -> tensor<16x1xf32>
          %24 = bufferization.to_buffer %16 : tensor<16x1xf32> to memref<16x1xf32, 2 : i64>
          %25 = bufferization.to_buffer %17 : tensor<16x4xf32> to memref<16x4xf32, 2 : i64>
          scf.for %26 = %autogen_0_index to %autogen_16_index step %autogen_1_index {
            scf.for %27 = %autogen_0_index to %autogen_4_index step %autogen_1_index {
              %28 = memref.load %25[%26, %27] : memref<16x4xf32, 2 : i64>
              %29 = arith.constant 0 : index
              %30 = memref.load %24[%26, %29] : memref<16x1xf32, 2 : i64>
              %31 = arith.addf %28, %30 : f32
              memref.store %31, %24[%26, %29] : memref<16x1xf32, 2 : i64>
            }
          }
          %32 = affine.apply affine_map<()[s0] -> (s0)> ()[%18]
          %33 = "tensor.extract_slice"(%10, %autogen_0_index, %32, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 16, 1>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<16x8xf32>, index, index, index, index) -> tensor<16x1xf32>
          %34 = linalg.copy ins(%16 : tensor<16x1xf32>) outs(%33 : tensor<16x1xf32>) -> tensor<16x1xf32>
          scf.reduce
        }) {memory_tag = "L1"} : (index, index, index) -> ()
      }
      "scf.parallel"(%autogen_0_index, %autogen_1_index, %autogen_1_index) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^2(%35 : index):
        %36 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<16x1xf32>
        %37 = bufferization.alloc_tensor() {memory_space = 2 : i64} : tensor<16x8xf32>
        %38 = affine.apply affine_map<()[s0] -> (s0)> ()[%35]
        %39 = "tensor.extract_slice"(%10, %autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 16, 8>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<16x8xf32>, index, index, index, index) -> tensor<16x8xf32>
        %40 = linalg.copy ins(%39 : tensor<16x8xf32>) outs(%37 : tensor<16x8xf32>) -> tensor<16x8xf32>
        %41 = arith.constant 0.000000e+00 : f32
        %42 = linalg.fill ins(%41 : f32) outs(%36 : tensor<16x1xf32>) -> tensor<16x1xf32>
        %43 = bufferization.to_buffer %36 : tensor<16x1xf32> to memref<16x1xf32, 2 : i64>
        %44 = bufferization.to_buffer %37 : tensor<16x8xf32> to memref<16x8xf32, 2 : i64>
        scf.for %45 = %autogen_0_index to %autogen_16_index step %autogen_1_index {
          scf.for %46 = %autogen_0_index to %autogen_8_index step %autogen_1_index {
            %47 = memref.load %44[%45, %46] : memref<16x8xf32, 2 : i64>
            %48 = arith.constant 0 : index
            %49 = memref.load %43[%45, %48] : memref<16x1xf32, 2 : i64>
            %50 = arith.addf %47, %49 : f32
            memref.store %50, %43[%45, %48] : memref<16x1xf32, 2 : i64>
          }
        }
        %51 = "tensor.extract_slice"(%36, %autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 16, 1>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<16x1xf32>, index, index, index, index) -> tensor<16x1xf32>
        %52 = linalg.copy ins(%51 : tensor<16x1xf32>) outs(%8 : tensor<16x1xf32>) -> tensor<16x1xf32>
        scf.reduce
      }) {memory_tag = "L1"} : (index, index, index) -> ()
      %53 = "tensor.extract_slice"(%2, %autogen_0_index, %autogen_0_index, %autogen_1_index, %autogen_1_index) <{static_offsets = array<i64: -9223372036854775808, -9223372036854775808>, static_sizes = array<i64: 16, 1>, static_strides = array<i64: -9223372036854775808, -9223372036854775808>, operandSegmentSizes = array<i32: 1, 2, 0, 2>}> : (tensor<16x1xf32>, index, index, index, index) -> tensor<16x1xf32>
      %54 = linalg.copy ins(%8 : tensor<16x1xf32>) outs(%53 : tensor<16x1xf32>) -> tensor<16x1xf32>
      scf.reduce
    }) {memory_tag = "L2"} : (index, index, index) -> ()
    func.return
  }
}

        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    "one-shot-bufferize",
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        
        
        shape = (16,32)
        total_size=16*32
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        print(input_a)
        input_a = input_a.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 16, num_samples),  # i indices
                np.random.randint(0, 1, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                sum(input_a[i]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (16,1),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        outputs = np.array([sum(input_a[i]) for i in range(16)],dtype=INPUT_DATATYPE).reshape((16,1))
        ###### Compile and test
        runner = XRTRunner(
            verbose=True,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a],
                # expected_outputs=[outputs],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

