# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @elementwise_add(%arg0 : memref<16x32xf32, 0 : i32>, %arg1 : memref<16x1xf32, 0 : i32>) {
    %autogen_zero = arith.constant 0 : index
    %autogen_one = arith.constant 1 : index
    %autogen_4_index = arith.constant 4 : index
    "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
    ^0(%0 : index):
      %arg1_l3 = memref.subview %arg1[0, 0] [16, 1] [1, 1] : memref<16x1xf32, 0 : i32> to memref<16x1xf32, strided<[1, 1]>, 0 : i32>
      %1 = memref.subview %arg0[0, 0] [16, 32] [1, 1] : memref<16x32xf32, 0 : i32> to memref<16x32xf32, strided<[32, 1]>, 0 : i32>
      %2 = affine.apply affine_map<()[s0] -> (s0)> ()[%0]
      %arg0_l2 = memref.alloc() : memref<16x32xf32, 1 : i32>
      "memref.copy"(%1, %arg0_l2) : (memref<16x32xf32, strided<[32, 1]>, 0 : i32>, memref<16x32xf32, 1 : i32>) -> ()
      %reduce_combine_res = memref.alloc() : memref<16x4xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_4_index, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%3 : index):
        %4 = affine.apply affine_map<()[s0] -> ((s0 * 8))> ()[%3]
        %5 = memref.subview %arg0_l2[0, %4] [16, 8] [1, 1] : memref<16x32xf32, 1 : i32> to memref<16x8xf32, strided<[32, 1], offset: ?>, 1 : i32>
        %6 = affine.apply affine_map<()[s0] -> (s0)> ()[%3]
        %arg0_l1 = memref.alloc() : memref<16x8xf32, 2 : i32>
        "memref.copy"(%5, %arg0_l1) : (memref<16x8xf32, strided<[32, 1], offset: ?>, 1 : i32>, memref<16x8xf32, 2 : i32>) -> ()
        %reduce_res_nd = memref.alloc() : memref<16x1xf32, 2 : i32>
        %7 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%7 : f32) outs(%reduce_res_nd : memref<16x1xf32, 2 : i32>)
        %8 = arith.constant 0 : index
        %9 = arith.constant 1 : index
        %10 = arith.constant 16 : index
        %11 = arith.constant 8 : index
        scf.for %12 = %8 to %10 step %9 {
          scf.for %13 = %8 to %11 step %9 {
            %14 = memref.load %arg0_l1[%12, %13] : memref<16x8xf32, 2 : i32>
            %15 = arith.constant 0 : index
            %16 = memref.load %reduce_res_nd[%12, %15] : memref<16x1xf32, 2 : i32>
            %17 = arith.addf %14, %16 : f32
            memref.store %17, %reduce_res_nd[%12, %15] : memref<16x1xf32, 2 : i32>
          }
        }
        %18 = affine.apply affine_map<()[s0] -> (s0)> ()[%3]
        %19 = memref.subview %reduce_combine_res[0, %18] [16, 1] [1, 1] : memref<16x4xf32, 1 : i32> to memref<16x1xf32, strided<[4, 1], offset: ?>, 1 : i32>
        "memref.copy"(%reduce_res_nd, %19) : (memref<16x1xf32, 2 : i32>, memref<16x1xf32, strided<[4, 1], offset: ?>, 1 : i32>) -> ()
        memref.dealloc %arg0_l1 : memref<16x8xf32, 2 : i32>
        memref.dealloc %reduce_res_nd : memref<16x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      %autogen_1_index = arith.constant 1 : index
      %reduce_res_l2 = memref.alloc() : memref<16x1xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_1_index, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^2(%20 : index):
        %reduce_combine_res_l2 = memref.subview %reduce_combine_res[0, 0] [16, 4] [1, 1] : memref<16x4xf32, 1 : i32> to memref<16x4xf32, strided<[4, 1]>, 1 : i32>
        %21 = affine.apply affine_map<()[s0] -> (s0)> ()[%20]
        %reduce_combine_res_l1 = memref.alloc() : memref<16x4xf32, 2 : i32>
        "memref.copy"(%reduce_combine_res_l2, %reduce_combine_res_l1) : (memref<16x4xf32, strided<[4, 1]>, 1 : i32>, memref<16x4xf32, 2 : i32>) -> ()
        %reduce_res_nd2 = memref.alloc() : memref<16x1xf32, 2 : i32>
        %22 = arith.constant 0.000000e+00 : f32
        linalg.fill ins(%22 : f32) outs(%reduce_res_nd2 : memref<16x1xf32, 2 : i32>)
        %23 = arith.constant 0 : index
        %24 = arith.constant 1 : index
        %25 = arith.constant 16 : index
        %26 = arith.constant 4 : index
        scf.for %27 = %23 to %25 step %24 {
          scf.for %28 = %23 to %26 step %24 {
            %29 = memref.load %reduce_combine_res_l1[%27, %28] : memref<16x4xf32, 2 : i32>
            %30 = arith.constant 0 : index
            %31 = memref.load %reduce_res_nd2[%27, %30] : memref<16x1xf32, 2 : i32>
            %32 = arith.addf %29, %31 : f32
            memref.store %32, %reduce_res_nd2[%27, %30] : memref<16x1xf32, 2 : i32>
          }
        }
        %33 = affine.apply affine_map<()[s0] -> (s0)> ()[%20]
        "memref.copy"(%reduce_res_nd2, %reduce_res_l2) : (memref<16x1xf32, 2 : i32>, memref<16x1xf32, 1 : i32>) -> ()
        memref.dealloc %reduce_combine_res_l1 : memref<16x4xf32, 2 : i32>
        memref.dealloc %reduce_res_nd2 : memref<16x1xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%reduce_res_l2, %arg1_l3) : (memref<16x1xf32, 1 : i32>, memref<16x1xf32, strided<[1, 1]>, 0 : i32>) -> ()
      memref.dealloc %arg0_l2 : memref<16x32xf32, 1 : i32>
      memref.dealloc %reduce_combine_res : memref<16x4xf32, 1 : i32>
      memref.dealloc %reduce_res_l2 : memref<16x1xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index) -> ()
    func.return
  }
}

        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        
        
        shape = (16,32)
        total_size=16*32
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        print(input_a)
        input_a = input_a.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 16, num_samples),  # i indices
                np.random.randint(0, 1, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                sum(input_a[i]) for i, j in zip(*sampled_indices)
            ], dtype=INPUT_DATATYPE
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (16,1),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        outputs = np.array([sum(input_a[i]) for i in range(16)],dtype=INPUT_DATATYPE).reshape((16,1))
        ###### Compile and test
        runner = XRTRunner(
            verbose=True,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a],
                # expected_outputs=[outputs],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

