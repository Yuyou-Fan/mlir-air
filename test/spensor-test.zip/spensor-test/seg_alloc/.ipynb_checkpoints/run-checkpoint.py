import air
import air.compiler.util
from air.dialects import linalg, tensor, arith, func, memref
from air.ir import *
import air.passmanager
from air.dialects import air as airdialect
from air.compiler.util import run_transform
import sys

with air.ir.Context() as ctx, Location.unknown():

    ################################################
    ## Tiling
    ################################################

    air_tiled_ir_string = """
builtin.module {
  func.func @elementwise_add(%arg0 : memref<16x32xf32, 0 : i32>, %arg1 : memref<16x32xf32, 0 : i32>) {
    %0 = arith.constant 0 : index
    %1 = arith.constant 1 : index
    %2 = arith.constant 2 : index
    %3 = arith.constant 2 : index
    "scf.parallel"(%0, %0, %2, %3, %1, %1) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
    ^0(%4 : index, %5 : index):
      %6 = affine.apply affine_map<()[s0] -> ((s0 * 8))> ()[%5]
      %7 = affine.apply affine_map<()[s0] -> ((s0 * 16))> ()[%4]
      %arg1_l3 = memref.subview %arg1[%6, %7] [8, 16] [1, 1] : memref<16x32xf32, 0 : i32> to memref<8x16xf32, strided<[32, 1], offset: ?>>
      %8 = affine.apply affine_map<()[s0] -> ((s0 * 8))> ()[%5]
      %9 = affine.apply affine_map<()[s0] -> ((s0 * 16))> ()[%4]
      %arg0_l3 = memref.subview %arg0[%8, %9] [8, 16] [1, 1] : memref<16x32xf32, 0 : i32> to memref<8x16xf32, strided<[32, 1], offset: ?>>
      %10 = affine.apply affine_map<()[s0, s1] -> (((s0 * 2) + s1))> ()[%4, %5]
      %arg0_l2 = memref.alloc() : memref<8x16xf32, 1 : i32>
      "memref.copy"(%arg0_l3, %arg0_l2) : (memref<8x16xf32, strided<[32, 1], offset: ?>>, memref<8x16xf32, 1 : i32>) -> ()
      %11 = arith.constant 0 : index
      %12 = arith.constant 1 : index
      %add_res_l2 = memref.alloc() : memref<8x16xf32, 1 : i32>
      "scf.parallel"(%11, %12, %12) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%13 : index):
        %14 = affine.apply affine_map<()[s0, s1] -> (((s0 * 2) + s1))> ()[%4, %5]
        %arg0_l1 = memref.alloc() : memref<8x16xf32, 2 : i32>
        "memref.copy"(%arg0_l2, %arg0_l1) : (memref<8x16xf32, 1 : i32>, memref<8x16xf32, 2 : i32>) -> ()
        %add_res_nd = memref.alloc() : memref<8x16xf32, 2 : i32>
        %15 = arith.constant 0 : index
        %16 = arith.constant 1 : index
        %17 = arith.constant 8 : index
        %18 = arith.constant 16 : index
        scf.for %19 = %15 to %17 step %16 {
          scf.for %20 = %15 to %18 step %16 {
            %21 = memref.load %arg0_l1[%19, %20] : memref<8x16xf32, 2 : i32>
            %22 = memref.load %arg0_l1[%19, %20] : memref<8x16xf32, 2 : i32>
            %23 = arith.addf %21, %22 : f32
            memref.store %23, %add_res_nd[%19, %20] : memref<8x16xf32, 2 : i32>
          }
        }
        %24 = affine.apply affine_map<()[s0] -> (s0)> ()[%13]
        "memref.copy"(%add_res_nd, %add_res_l2) : (memref<8x16xf32, 2 : i32>, memref<8x16xf32, 1 : i32>) -> ()
        memref.dealloc %arg0_l1 : memref<8x16xf32, 2 : i32>
        memref.dealloc %add_res_nd : memref<8x16xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%add_res_l2, %arg1_l3) : (memref<8x16xf32, 1 : i32>, memref<8x16xf32, strided<[32, 1], offset: ?>>) -> ()
      memref.dealloc %arg0_l2 : memref<8x16xf32, 1 : i32>
      memref.dealloc %add_res_l2 : memref<8x16xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index, index, index, index) -> ()
    func.return
  }
}
    """
    air_module = Module.parse(air_tiled_ir_string)
    #print(air_module)

    ################################################
    ## Binding scf.paralell to air hierarchies
    ################################################

    pipeline = (
        "builtin.module("
        + ",".join(
            [
                # Convert to AIR Option 1
                "air-insert-launch-around-herd{insert-segment=true}",
                 "func.func(air-lower-herd-parallel)",
                # # Convert to AIR option 2
                 "air-par-to-herd{depth=-1}",
                 "air-par-to-launch{depth=0 has-air-segment=true}",
                 "scf-forall-to-for",
                # # End
                 "air-copy-to-dma",
                #  "air-dependency",
                # "air-dependency-schedule-opt",
                # "air-specialize-dma-broadcast",
                # "air-dma-to-channel,canonicalize",
                # "cse",
                # "air-dependency-canonicalize",
                # "canonicalize",
                # "cse",
                # "air-isolate-async-dma-loop-nests",
                # "canonicalize,cse",
                # "air-fuse-channels",
                # "canonicalize,cse",
                # "func.func(air-split-l2-memref)",
                # "canonicalize,cse",
                # "air-isolate-async-dma-loop-nests",
                # "canonicalize,cse",
                # "func.func(air-fuse-alloc-dealloc)",
                # "func.func(air-shrink-memref-sizes-by-access)",
                # "func.func(convert-linalg-to-loops)",
                # "func.func(air-opt-memtile-dma-bds{device=npu1_4col})",
                # "canonicalize,cse",
                # "func.func(air-collapse-herd{max-col-size=4 })",
                # "canonicalize,cse",
                # "air-place-herds{num-rows=6 num-cols=4 row-anchor=2 col-anchor=0}",
                # "canonicalize,cse",
                # "func.func(air-renumber-dma)"
            ]
        )
        + ")"
    )
    pm = air.passmanager.PassManager.parse(pipeline)
    pm.run(air_module.operation)
    #print(air_module)

    # ################################################
    # ## MLIR-AIR to MLIR-AIE
    # ################################################

    # pipeline = (
    #     "builtin.module("
    #     + ",".join(
    #         [
    #             "canonicalize",
    #             "cse",
    #             "air-to-aie{row-offset=2 col-offset=0 device=npu1_4col emit-while-loop=true}",
    #             "canonicalize",
    #         ]
    #     )
    #     + ")"
    # )
    # pm = air.passmanager.PassManager.parse(pipeline)
    # pm.run(air_module.operation)
    # #print(air_module)

    # # ################################################
    # # ## MLIR-AIR runtime lowering
    # # ################################################

    # pipeline = (
    #     "builtin.module("
    #     + ",".join(
    #         [
    #             "func.func(air-opt-shim-dma-bds{device=npu1_4col shim-dma-tile-sizes=4,4})",
    #             "air-to-std",
    #             "canonicalize",
    #             "symbol-dce",
    #             "affine-expand-index-ops",
    #             "airrt-to-npu",
    #             "canonicalize",
    #         ]
    #     )
    #     + ")"
    # )
    # pm = air.passmanager.PassManager.parse(pipeline)
    # pm.run(air_module.operation)
    with open("aieDebug.mlir", "w") as f:
        print(air_module)
        f.write(str(air_module))
