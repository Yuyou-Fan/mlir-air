# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
builtin.module {
  func.func @elementwise_add(%arg0 : memref<16x32xf32, 0 : i32>, %arg1 : memref<16x32xf32, 0 : i32>) {
    %autogen_zero = arith.constant 0 : index
    %autogen_one = arith.constant 1 : index
    %autogen_2_index = arith.constant 2 : index
    %autogen_2_index_1 = arith.constant 2 : index
    "scf.parallel"(%autogen_zero, %autogen_zero, %autogen_2_index, %autogen_2_index_1, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 2, 2, 2, 0>}> ({
    ^0(%0 : index, %1 : index):
      %2 = affine.apply affine_map<()[s0] -> ((s0 * 8))> ()[%0]
      %3 = affine.apply affine_map<()[s0] -> ((s0 * 16))> ()[%1]
      %arg1_l3 = memref.subview %arg1[%2, %3] [8, 16] [1, 1] : memref<16x32xf32, 0 : i32> to memref<8x16xf32, strided<[32, 1], offset: ?>, 0 : i32>
      %4 = affine.apply affine_map<()[s0] -> ((s0 * 8))> ()[%0]
      %5 = affine.apply affine_map<()[s0] -> ((s0 * 16))> ()[%1]
      %arg0_l3 = memref.subview %arg0[%4, %5] [8, 16] [1, 1] : memref<16x32xf32, 0 : i32> to memref<8x16xf32, strided<[32, 1], offset: ?>, 0 : i32>
      %6 = affine.apply affine_map<()[s0, s1] -> (((s0 * 2) + s1))> ()[%0, %1]
      %arg0_l2 = memref.alloc() : memref<8x16xf32, 1 : i32>
      "memref.copy"(%arg0_l3, %arg0_l2) : (memref<8x16xf32, strided<[32, 1], offset: ?>, 0 : i32>, memref<8x16xf32, 1 : i32>) -> ()
      %add_res_l2 = memref.alloc() : memref<8x16xf32, 1 : i32>
      "scf.parallel"(%autogen_zero, %autogen_one, %autogen_one) <{operandSegmentSizes = array<i32: 1, 1, 1, 0>}> ({
      ^1(%7 : index):
        %8 = affine.apply affine_map<()[s0, s1] -> (((s0 * 2) + s1))> ()[%0, %1]
        %arg0_l1 = memref.alloc() : memref<8x16xf32, 2 : i32>
        "memref.copy"(%arg0_l2, %arg0_l1) : (memref<8x16xf32, 1 : i32>, memref<8x16xf32, 2 : i32>) -> ()
        %add_res_nd = memref.alloc() : memref<8x16xf32, 2 : i32>
        linalg.add ins(%arg0_l1, %arg0_l1 : memref<8x16xf32, 2 : i32>, memref<8x16xf32, 2 : i32>) outs(%add_res_nd : memref<8x16xf32, 2 : i32>)
        %9 = affine.apply affine_map<()[s0] -> (s0)> ()[%7]
        "memref.copy"(%add_res_nd, %add_res_l2) : (memref<8x16xf32, 2 : i32>, memref<8x16xf32, 1 : i32>) -> ()
        memref.dealloc %arg0_l1 : memref<8x16xf32, 2 : i32>
        memref.dealloc %add_res_nd : memref<8x16xf32, 2 : i32>
        scf.reduce
      }) {memory_tag = 2 : index} : (index, index, index) -> ()
      "memref.copy"(%add_res_l2, %arg1_l3) : (memref<8x16xf32, 1 : i32>, memref<8x16xf32, strided<[32, 1], offset: ?>, 0 : i32>) -> ()
      memref.dealloc %arg0_l2 : memref<8x16xf32, 1 : i32>
      memref.dealloc %add_res_l2 : memref<8x16xf32, 1 : i32>
      scf.reduce
    }) {memory_tag = 1 : index} : (index, index, index, index, index, index) -> ()
    func.return
  }
}

        """
        mlir_module = Module.parse(air_tiled_ir_string)
        #print(air_module)
    
        ################################################
        ## Binding scf.paralell to air hierarchies
        ################################################
    
        pipeline = (
            "builtin.module("
            + ",".join(
                [
                    # Convert to AIR Option 1
                    "air-insert-launch-around-herd{insert-segment=true}",
                     "func.func(air-lower-herd-parallel)",
                    # # Convert to AIR option 2
                     "air-par-to-herd{depth=-1}",
                     "air-par-to-launch{depth=0 has-air-segment=true}",
                     "scf-forall-to-for",
                    # # End
                     "air-copy-to-dma",
                ]
            )
            + ")"
        )
        pm = air.passmanager.PassManager.parse(pipeline)
        pm.run(mlir_module.operation)
        
        
        shape = (16,32)
        total_size=16*32
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        print(input_a)
        input_a = input_a.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 16, num_samples),  # i indices
                np.random.randint(0, 32, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                (input_a[i, j]+input_a[i,j]) for i, j in zip(*sampled_indices)
            ]
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (16,32),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        ###### Compile and test
        runner = XRTRunner(
            verbose=True,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

