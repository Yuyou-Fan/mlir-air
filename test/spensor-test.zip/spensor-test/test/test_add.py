# Copyright (C) 2025, Advanced Micro Devices, Inc.
# SPDX-License-Identifier: MIT
import argparse
from ml_dtypes import bfloat16

import air
from air.ir import *
from air.dialects.affine import apply as affine_apply
from air.dialects.air import *
from air.dialects.arith import ConstantOp
from air.dialects.memref import AllocOp, DeallocOp, load, store
from air.dialects.func import FuncOp
from air.dialects.scf import for_, yield_
from air.backend.xrt_runner import XRTRunner, type_mapper
from air.backend.xrt import XRTBackend

range_ = for_

if __name__ == "__main__":
    # Default values.
    N = 65536
    TILE_N = 1024
    INPUT_DATATYPE = np.float32

    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Builds, runs, and tests the passthrough_dma example",
    )
    parser.add_argument(
        "-p",
        "--print-module-only",
        action="store_true",
    )
    parser.add_argument(
        "--n",
        type=int,
        default=N,
        help="Total number of elements",
    )
    parser.add_argument("--tile-n", type=int, default=TILE_N, help="Tile size")
    args = parser.parse_args()

    with air.ir.Context() as ctx, Location.unknown():
    
        ################################################
        ## Tiling
        ################################################
    
        air_tiled_ir_string = """
#map = affine_map<()[s0] -> (s0 * 64)>
module {
  func.func @elementwise_add(%arg0: memref<256x64xf32>, %arg1: memref<256x64xf32>, %arg2: memref<256x64xf32>) {
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    air.herd @herd_0  tile (%arg3, %arg4) in (%arg5=%c4, %arg6=%c1) args(%arg7=%arg2, %arg8=%arg1, %arg9=%arg0) : memref<256x64xf32>, memref<256x64xf32>, memref<256x64xf32> {
      %c1_0 = arith.constant 1 : index
      %c64 = arith.constant 64 : index
      %c0 = arith.constant 0 : index
      %0 = affine.apply #map()[%arg3]
      %1 = affine.apply #map()[%arg3]
      %alloc = memref.alloc() : memref<64x64xf32, 2 : i32>
      air.dma_memcpy_nd (%alloc[] [] [], %arg8[%1, %c0] [%c64, %c64] [%c64, %c1_0]) {id = 1 : i32} : (memref<64x64xf32, 2 : i32>, memref<256x64xf32>)
      %2 = affine.apply #map()[%arg3]
      %alloc_1 = memref.alloc() : memref<64x64xf32, 2 : i32>
      air.dma_memcpy_nd (%alloc_1[] [] [], %arg9[%2, %c0] [%c64, %c64] [%c64, %c1_0]) {id = 2 : i32} : (memref<64x64xf32, 2 : i32>, memref<256x64xf32>)
      %alloc_2 = memref.alloc() : memref<64x64xf32, 2 : i32>
      linalg.add ins(%alloc_1, %alloc : memref<64x64xf32, 2 : i32>, memref<64x64xf32, 2 : i32>) outs(%alloc_2 : memref<64x64xf32, 2 : i32>)
      air.dma_memcpy_nd (%arg7[%0, %c0] [%c64, %c64] [%c64, %c1_0], %alloc_2[] [] []) {id = 3 : i32} : (memref<256x64xf32>, memref<64x64xf32, 2 : i32>)
      memref.dealloc %alloc : memref<64x64xf32, 2 : i32>
      memref.dealloc %alloc_1 : memref<64x64xf32, 2 : i32>
      memref.dealloc %alloc_2 : memref<64x64xf32, 2 : i32>
    }
    return
  }
}

        """
        mlir_module = Module.parse(air_tiled_ir_string)

        shape = (256,64)
        total_size=256*64
        input_a = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_a = input_a.astype(INPUT_DATATYPE)
        input_b = np.arange(0, total_size, dtype=np.int64).reshape(shape)
        input_b = input_b.astype(INPUT_DATATYPE)
        num_samples = 100
        sampled_indices = np.vstack(
            [
                np.random.randint(0, 256, num_samples),  # i indices
                np.random.randint(0, 64, num_samples),  # j indices
            ]
        )
    
        # Compute reference results for sampled indices
        sampled_values = np.array(
            [
                (input_a[i, j] + input_b[i, j]) for i, j in zip(*sampled_indices)
            ]
        )
    
        # Store as a dictionary
        sampled_data = {
            "shape": (256,64),
            "indices": sampled_indices,
            "values": sampled_values,
        }
    
        ###### Compile and test
        runner = XRTRunner(
            verbose=False,
            omit_while_true_loop=False,
        )
        exit(
            runner.run_test(
                mlir_module,
                inputs=[input_a, input_b],
                stochastic_expected_outputs=[sampled_data],
                rtol=1e-3,
            )
        )

